/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productsake;
/**
 *
 * @author Student
 */
public class ProductSake {

}
{


ProductSalesApp

src/
    IProduct.java
    Product.java
    PrintProduct.java
    ProductApp.java         <- Q1.1 Main
    IProductCalculations.java
    ProductCalculations.java
    ProductGUI.java         <- Q2 GUI
  test/
    ProductTest.java        <- Q1.4
    ProductCalculationsTest.java <- Q2.6  

public interface IProduct {

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}

public class Product implements IProduct {

    private String[] products;
    private int[][] sales; // [product][month]

    public Product(String[] products, int[][] sales) -{
        this.products = products;
        this.sales = sales;
    }

    @Override// get the total product sold
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }
        return total;
    }

    @Override// avarerage number of the product that are sold per product
    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = sales.length * sales[0].length; // 3 x 3 = 9
        return (double) total / count;
    }

    @Override // most popular products on high sales
    public String GetMostPopularProduct() {
        // Find product with highest TOTAL sales
        int maxTotal = -1;
        int maxIndex = 0;
        int maxSingleSale = 0;

        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            int productMax = 0;
            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];
                if (sales[i][j] > productMax) {
                    productMax = sales[i][j];
                }
            }
            if (productTotal > maxTotal) {
                maxTotal = productTotal;
                maxIndex = i;
                maxSingleSale = productMax;
            }
        }
        // Matches screenshot: Cozy Nights Monarch(25)
        return products[maxIndex] + "(" + maxSingleSale + ")";
    }
}
