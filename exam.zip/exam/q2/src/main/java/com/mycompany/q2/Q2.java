
package com.mycompany.q2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Q2 {

    private static class ProductSales {

        public ProductSales() {
        }

        private int TotalSales(int[][] productSales) {
            int total = 0;

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {
                    total += productSales[i][j];
                }
            }

            return total;
        }

        private double AverageSales(int[][] productSales) {
            int total = TotalSales(productSales);
            int count = 0;

            for (int i = 0; i < productSales.length; i++) {
                count += productSales[i].length;
            }

            return (double) total / count;
        }
    }

    public static class ProductSalesGUI extends JFrame {

        private JButton btnLoad;
        private JButton btnSave;
        private JTextArea txtDisplay;
        private JLabel lblYearsProcessed;

        private int[][] productSales;

        private final int SALES_LIMIT = 500;
        private final int YEARS = 2;

        public ProductSalesGUI() {

            setTitle("Product Sales Application");
            setSize(350, 280);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLayout(new BorderLayout());

            // Menu Bar
            JMenuBar menuBar = new JMenuBar();

            JMenu fileMenu = new JMenu("File");
            JMenu editMenu = new JMenu("Edit");

            menuBar.add(fileMenu);
            menuBar.add(editMenu);

            setJMenuBar(menuBar);

            // Buttons
            JPanel topPanel = new JPanel();
            topPanel.setLayout(new GridLayout(2, 1, 5, 5));

            btnLoad = new JButton("Load Product Data");
            btnSave = new JButton("Save Product Data");

            topPanel.add(btnLoad);
            topPanel.add(btnSave);

            // Text Area
            txtDisplay = new JTextArea();
            txtDisplay.setEditable(false);
            txtDisplay.setBorder(
                BorderFactory.createLineBorder(Color.GRAY)
            );

            JScrollPane scrollPane = new JScrollPane(txtDisplay);

            // Years Processed Label
            lblYearsProcessed = new JLabel("Years Processed: 0");
            lblYearsProcessed.setFont(
                new Font("Arial", Font.BOLD, 12)
            );

            add(topPanel, BorderLayout.NORTH);
            add(scrollPane, BorderLayout.CENTER);
            add(lblYearsProcessed, BorderLayout.SOUTH);

            // Load Button
            btnLoad.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loadProductData();
                }
            });

            // Save Button
            btnSave.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    saveProductData();
                }
            });
        }

        private void loadProductData() {

            productSales = new int[][] {
                {300, 150, 700},
                {250, 200, 600}
            };

            ProductSales ps = new ProductSales();

            int total = ps.TotalSales(productSales);
            double average = ps.AverageSales(productSales);

            int overLimit = 0;
            int underLimit = 0;

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {

                    if (productSales[i][j] >= SALES_LIMIT) {
                        overLimit++;
                    } else {
                        underLimit++;
                    }
                }
            }

            // Display results
            txtDisplay.setText("Total Sales: " + total + "\n");

            txtDisplay.append(
                "Average Sales: " + Math.round(average) + "\n"
            );

            txtDisplay.append(
                "Sales over limit: " + overLimit + "\n"
            );

            txtDisplay.append(
                "Sales under limit: " + underLimit
            );

            // Update years processed
            lblYearsProcessed.setText(
                "Years Processed: " + YEARS
            );
        }

        private void saveProductData() {

            if (productSales == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "Please load product data first!"
                );
                return;
            }

            JFileChooser fileChooser = new JFileChooser();

            int result = fileChooser.showSaveDialog(this);

            if (result == JFileChooser.APPROVE_OPTION) {

                try {
                    FileWriter writer = new FileWriter(
                        fileChooser.getSelectedFile()
                    );

                    writer.write(txtDisplay.getText());

                    writer.write(
                        "\n" + lblYearsProcessed.getText()
                    );

                    writer.close();

                    JOptionPane.showMessageDialog(
                        this,
                        "Data saved successfully!"
                    );

                } catch (IOException ex) {

                    JOptionPane.showMessageDialog(
                        this,
                        "Error saving file: " + ex.getMessage()
                    );
                }
            }
        }
    }

    // Main Method
    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                ProductSalesGUI gui = new ProductSalesGUI();

                gui.setVisible(true);
            }
        });
    }
}


