/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.productapp;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class PrintProductTest {
    
    public PrintProductTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of PrintTotalProductSales method, of class PrintProduct.
     */
    @Test
    public void testPrintTotalProductSales() {
        System.out.println("PrintTotalProductSales");
        Product product = null;
        PrintProduct instance = new PrintProduct();
        instance.PrintTotalProductSales(product);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PrintAverageProductSales method, of class PrintProduct.
     */
    @Test
    public void testPrintAverageProductSales() {
        System.out.println("PrintAverageProductSales");
        Product product = null;
        PrintProduct instance = new PrintProduct();
        instance.PrintAverageProductSales(product);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PrintMostPopularProduct method, of class PrintProduct.
     */
    @Test
    public void testPrintMostPopularProduct() {
        System.out.println("PrintMostPopularProduct");
        Product product = null;
        PrintProduct instance = new PrintProduct();
        instance.PrintMostPopularProduct(product);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
