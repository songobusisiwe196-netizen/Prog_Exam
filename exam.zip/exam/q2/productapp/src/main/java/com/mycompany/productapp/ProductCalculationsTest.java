
package com.mycompany.productapp;

public class ProductCalculationsTest {

    ProductCalculations calc = new ProductCalculations(3500);

    
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        assertEquals(525.0, calc.GetVat(), 0.01);
    }

   
    public void GetCommission_WithValidData_ReturnsCorrectValue() {
        assertEquals(175.0, calc.GetCommission(), 0.01);
    }

   
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        assertEquals(4200.0, calc.GetTotal(), 0.01);
    }

    private void assertEquals(double d, double GetTotal, double d0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
