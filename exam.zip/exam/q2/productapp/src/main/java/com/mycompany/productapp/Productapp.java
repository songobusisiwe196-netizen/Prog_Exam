/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productapp;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Productapp {

public class ProductApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1D arrays
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        // 2D array [3 products][3 months]
        int[][] sales = new int[3][3];

        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + products[i] + " mattress: ");
                sales[i][j] = sc.nextInt();
            }
            System.out.println();
        }

        Product product = new Product(products, sales);
        PrintProduct printer = new PrintProduct();

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("********************************************");
        printer.PrintTotalProductSales(product);
        printer.PrintAverageProductSales(product);
        printer.PrintMostPopularProduct(product);
    }
}
    }
public class Product implements IProduct {
    private String[] products;
    private int[][] sales; // [product][month]

    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }

        public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }
        return total;
    }

        public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = sales.length * sales[0].length; // 3 x 3 = 9
        return (double) total / count;
    }

    public String GetMostPopularProduct() {
        // Find product with highest TOTAL sales
        int maxTotal = -1;
        int maxIndex = 0;
        int maxSingleSale = 0;

        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            int productMax = 0;
            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];
                if (sales[i][j] > productMax) {
                    productMax = sales[i][j];
                }
            }
            if (productTotal > maxTotal) {
                maxTotal = productTotal;
                maxIndex = i;
                maxSingleSale = productMax;
            }
        }
        // Matches screenshot: Cozy Nights Monarch(25)
        return products[maxIndex] + "(" + maxSingleSale + ")";
    }
}
public class PrintProduct {
    public void PrintTotalProductSales(Product product) {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales(Product product) {
        System.out.println("AVERAGE PRODUCT SALES: " + (int) product.GetAverageProductSold());
    }

    public void PrintMostPopularProduct(Product product) {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
