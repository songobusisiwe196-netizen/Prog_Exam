
package com.mycompany.productapp;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;

public class ProductGUI extends JFrame {

    private JTextField txtCustomerName, txtPrice;
    private JComboBox<String> cmbProduct;
    private JButton btnProcess;
    private JMenuItem mnuExit, mnuProcess, mnuClear;

    public ProductGUI() {

        setTitle("Product App");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout((java.awt.LayoutManager) (LayoutManager) new GridLayout(5, 2, 10, 10));

        // Menu
        JMenuBar bar = new JMenuBar();

        JMenu mnuFile = new JMenu("File");
        JMenu mnuTools = new JMenu("Tools");

        mnuExit = new JMenuItem("Exit");
        mnuProcess = new JMenuItem("Process");
        mnuClear = new JMenuItem("Clear");

        mnuFile.add(mnuExit);
        mnuTools.add(mnuProcess);
        mnuTools.add(mnuClear);

        bar.add(mnuFile);
        bar.add(mnuTools);

        setJMenuBar(bar);

        // Customer Name
        add(new JLabel("Customer Name:"));

        txtCustomerName = new JTextField();
        add(txtCustomerName);

        // Product
        add(new JLabel("Select Product:"));

        cmbProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        });

        add(cmbProduct);

        // Price
        add(new JLabel("Enter Price:"));

        txtPrice = new JTextField();
        add(txtPrice);

        // Process Button
        add(new JLabel(""));

        btnProcess = new JButton("PROCESS");
        add(btnProcess);

        // Button Events
        btnProcess.addActionListener(e -> processSale());
        mnuProcess.addActionListener(e -> processSale());
        mnuExit.addActionListener(e -> System.exit(0));
        mnuClear.addActionListener(e -> clearForm());
    }

    private void processSale() {

        try {

            String customer = txtCustomerName.getText();
            String product = (String) cmbProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText());

            ProductCalculations calc = new ProductCalculations(price);

            double vat = calc.GetVat();
            double commission = calc.GetCommission();
            double total = calc.GetTotal();

            String message = "Customer Name: " + customer + "\n"
                    + "Product: " + product + "\n"
                    + "VAT: R " + vat + "\n"
                    + "COMMISSION: R " + commission + "\n"
                    + "TOTAL: R " + total;

            JOptionPane.showMessageDialog(
                    this,
                    message,
                    "Message",
                    JOptionPane.INFORMATION_MESSAGE
            );

            // Save data to file
            FileWriter w = new FileWriter("data.txt");

            w.write("DATA LOG\n");
            w.write("********************************************\n");
            w.write("Customer Name: " + customer + "\n");
            w.write("Product: " + product + "\n");
            w.write("VAT: R " + vat + "\n");
            w.write("COMMISSION: R " + commission + "\n");
            w.write("TOTAL: R " + total + "\n");
            w.write("********************************************");

            w.close();

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Enter a valid price!"
            );

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving file!"
            );
        }
    }

    private void clearForm() {

        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);

        txtCustomerName.requestFocus();
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new ProductGUI().setVisible(true)
        );
    }

    private static class GridLayout implements LayoutManager {


        private GridLayout(int i, int i0, int i1, int i2) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
