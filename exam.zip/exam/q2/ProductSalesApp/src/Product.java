
public class Product extends IProduct {

    private String[] products;
    private int[][] sales; // [product][month]

    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }

    public int GetTotalProductsSold() {
        int total = 0;

        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }

        return total;
    }

    public double GetAverageProductSold() {
        int total = GetTotalProductsSold();
        int count = 0;

        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length;
        }

        if (count == 0) {
            return 0;
        }

        return (double) total / count;
    }

    public String GetMostPopularProduct() {
        int maxTotal = -1;
        int maxIndex = 0;
        int maxSingleSale = 0;

        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            int productMax = 0;

            for (int j = 0; j < sales[i].length; j++) {
                productTotal += sales[i][j];

                if (sales[i][j] > productMax) {
                    productMax = sales[i][j];
                }
            }

            if (productTotal > maxTotal) {
                maxTotal = productTotal;
                maxIndex = i;
                maxSingleSale = productMax;
            }
        }

        return products[maxIndex] + "(" + maxSingleSale + ")";
    }
}
