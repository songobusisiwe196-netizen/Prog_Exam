
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class IProduct {
   

    private static class PrintProduct {

        public PrintProduct() {
        }

        private void PrintMostPopularProduct(Product product) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void PrintAverageProductSales(Product product) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void PrintTotalProductSales(Product product) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class Product {

        public Product() {
        }

        private Product(String[] products, int[][] sales) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

public class ProductApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1D arrays
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        // 2D array [3 products][3 months]
        int[][] sales = new int[3][3];

        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + products[i] + " mattress: ");
                sales[i][j] = sc.nextInt();
            }
            System.out.println();
        }

        Product product = new Product(products, sales);
        PrintProduct printer = new PrintProduct();

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("********************************************");
        printer.PrintTotalProductSales(product);
        printer.PrintAverageProductSales(product);
        printer.PrintMostPopularProduct(product);
    }
}
}
